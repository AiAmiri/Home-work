public class Main {
	public static void main(String[] args) {
		System.out.println("CV For Aiatullah Amiri");
		System.out.println("");
		System.out.println("    Name : Aiatullah");
		System.out.println("    Last Name : Amiri");
		System.out.println("    Father Name : Gholam sarvar");
		System.out.println("    Gender : Male");
		System.out.println("    Age : 19 years");
		System.out.println("    Date of birth : 14/12/2005");
		System.out.println("    Nationality : Afghan");
		System.out.println("");
		System.out.println("Language Level ");
		System.out.println("    Main language : Dari");
		System.out.println("    Pashto : meduim");
		System.out.println("    English : A1");
		System.out.println("");
		System.out.println("Education");
		System.out.println("    High school : Mahmood tarzi");
		System.out.println("    University : Kabul");
		System.out.println("    Faculty : Computer since");
		System.out.println("    Department : Software engineering ");
		System.out.println("");
		System.out.println("Communication");
		System.out.println("    Phone : +93790976268");
		System.out.println("    Email : education.amiri@gmail.com");
	}
}